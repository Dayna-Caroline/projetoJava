public class Main{
	public static void main(String[] args ) throws ClassNotFoundException {  
	      DatabaseManager.inicializaUsuario();
	      
	      Login.inicializa();
	}
}
