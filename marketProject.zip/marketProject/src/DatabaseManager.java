import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseManager {
	static String url = "jdbc:HypersonicSQL:http://127.0.0.1:8080";
    static String user = "sa";
    static String password = "";
    
    static void inicializaUsuario() throws ClassNotFoundException {
    	Class.forName("org.hsql.jdbcDriver");
        
        try (Connection connection = DriverManager.getConnection(url, user, password)) {
    	   String createTableSQL = "CREATE TABLE usuario (" +
                                    "ID INTEGER IDENTITY PRIMARY KEY, " +
                                    "nome VARCHAR(255) NOT NULL, " +
                                    "login VARCHAR(100) NOT NULL, " +
                                    "senha VARCHAR(50) NOT NULL, " +
                                    "administrativo INTEGER)";
            try (Statement statement = connection.createStatement()) {
                statement.execute(createTableSQL);
                System.out.println("Tabela usuario criada com sucesso!");
            } catch (Exception e) {
            	System.out.println("Tabela usuario já existe, continuando...");
            }
            
            String verificaUsuarioAdm = "SELECT * FROM usuario WHERE login = 'adm'";
            boolean admExiste = false;
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(verificaUsuarioAdm)) {
                if (resultSet.next()) {
                	admExiste = true;
                }
            }
            
            if (!admExiste) {
            	String insereAdm = "INSERT INTO usuario (nome, login, senha, administrativo) VALUES ('Administrador', 'adm', 'adm', 1)";
                try (Statement statement = connection.createStatement()) {
                    statement.execute(insereAdm);
                    System.out.println("Administrador criado com sucesso!");
                }
            } else {
                System.out.println("Administrador já existe, continuando...");
            }

            String selectSQL = "SELECT ID, nome, login, senha, administrativo FROM usuario";
            try (PreparedStatement preparedStatement = connection.prepareStatement(selectSQL);
                 ResultSet resultSet = preparedStatement.executeQuery()) {
                 
                System.out.println("Dados na tabela Users:");
                while (resultSet.next()) {
                    int id = resultSet.getInt("ID");
                    String username = resultSet.getString("nome");
                    String email = resultSet.getString("login");
                    String senha = resultSet.getString("senha");
                    String adm = resultSet.getString("administrativo");
                    System.out.println("ID: " + id + ", Username: " + username + ", Email: " + email + ", Senha: " + senha + ", Administrativo: " + adm);
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    static boolean logar(String login, String senha) throws ClassNotFoundException, SQLException {
    	Class.forName("org.hsql.jdbcDriver");
        
        try (Connection connection = DriverManager.getConnection(url, user, password)) {
        	String verificaUsuario = "SELECT * FROM usuario WHERE login = '" + login + "' and senha = '" + senha + "';";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(verificaUsuario)) {
                if (resultSet.next()) {
                	return true;
                }
            }
        }
        
        return false;
    }

    static boolean verificaLogin(String login) throws ClassNotFoundException, SQLException {
    	Class.forName("org.hsql.jdbcDriver");
        
        try (Connection connection = DriverManager.getConnection(url, user, password)) {
        	String verificaUsuario = "SELECT * FROM usuario WHERE login = '" + login + "';";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(verificaUsuario)) {
                if (resultSet.next()) {
                	return true;
                }
            }
        }
        
        return false;
    }

    static boolean cadastrar(String nome, String login, String senha) throws ClassNotFoundException, SQLException {
    	Class.forName("org.hsql.jdbcDriver");
        
        try (Connection connection = DriverManager.getConnection(url, user, password)) {
        	String verificaUsuario = "INSERT INTO usuario (nome, login, senha, administrativo) VALUES ('" + nome + "', '" + login + "', '" + senha + "', 0)";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(verificaUsuario)) {
                 return true;
            }
        }
    }
    
    static String getUsuario(String login) throws ClassNotFoundException, SQLException {
    	Class.forName("org.hsql.jdbcDriver");
    	
    	String nome = ""; 
        
        try (Connection connection = DriverManager.getConnection(url, user, password)) {
        	String verificaUsuario = "SELECT nome FROM usuario WHERE login = '" + login + "';";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(verificaUsuario)) {
                if (resultSet.next()) {
                	nome = resultSet.getString("nome");
                }
            }
        }
        
        return nome;
    }
}
